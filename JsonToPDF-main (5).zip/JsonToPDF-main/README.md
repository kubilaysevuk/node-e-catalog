
# JsonToPDF
Merhaba bu proje ile json ile çektiğiniz veriyi kendi yaptığınız veya benim yaptığım html templatei ile PDF dosyasına çevirebilirsiniz.

## Nasıl mı kuruluyor?
İlk olarak projeyi klonlayın veya indirin ondan sonra proje konumunda komut istemcisi açıp `npm install` komutu çalıştırın.

### Nasıl çalıştıracağım
Komut istemcisine `node JsonToPDF.js` komutunu girerek çalıştırabilirsiniz.

## Lisans

[MIT](https://choosealicense.com/licenses/mit/)
