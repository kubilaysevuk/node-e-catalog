const axios = require('axios');

const fetchData = async () => {
  try {
    const response = await axios.get('http://oriongida.com/wp-json/custom/v2/products');
    return response.data;
  } catch (error) {
    console.error('Veri çekme hatası:', error.message);
    return { error: 'Veri çekme hatası', details: error.message };
  }
};

const getData = async () => {
  try {
    const remoteData = await fetchData();

    if (remoteData && !remoteData.error) {
      console.log(`Toplam ${remoteData.length} ürün koyuldu.`);

      return {
        items: remoteData,
      };
    } else {
      return {
        items: [
          {
            "urun_adi": "Ürünün adı alınamadı.",
            "marka": "Ürünü üreten marka alınamadı.",
            "cat_name": "Ürünün kategorisi alınamadı.",
            "stok_kodu": "Ürünün stok kodu alınamadı.",
          }
        ],
      };
    }
  } catch (error) {
    console.error('getData fonksiyonunda bir hata oluştu:', error.message);
    return { error: 'getData fonksiyonunda bir hata oluştu', details: error.message };
  }
};

module.exports = getData;